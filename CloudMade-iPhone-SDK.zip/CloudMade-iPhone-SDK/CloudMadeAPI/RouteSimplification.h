/*
 *  RouteSimplification.h
 *  CloudMadeApi
 *
 *  Created by Dmytro Golub on 1/18/10.
 *  Copyright 2010 CloudMade. All rights reserved.
 *
 */

//#ifdef __cplusplus
//extern "C" {
//#endif 

CLLocationCoordinate2D* simplifyRoute(CLLocationCoordinate2D* route,int *nCount,float distance);

//#ifdef __cplusplus
//}
//#endif 