//
//  CMRouting.h
//  CloudMadeApi
//
//  Created by Dmytro Golub on 11/9/09.
//  Copyright 2009 CloudMade. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CMRoutingDelegate
    
@end


@interface CMRouting : NSObject {
	NSString* apikey; /**< APIKEY  */
}

@end
