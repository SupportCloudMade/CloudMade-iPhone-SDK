//
//  RouteSummary.m
//  NavigationView
//
//  Created by Dmytro Golub on 4/10/09.
//  Copyright 2009 Cloudmade. All rights reserved.
//

#import "RouteSummary.h"



@implementation RouteSummary
@synthesize startPoint;
@synthesize endPoint;
@synthesize totalTime;
@synthesize totalDistance;
@end
