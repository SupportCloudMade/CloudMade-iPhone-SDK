//
//  untitled.m
//  Routing
//
//  Created by Dmytro Golub on 12/14/09.
//  Copyright 2009 CloudMade. All rights reserved.
//

#import "CMRouteDetails.h"


@implementation CMRouteDetails

@synthesize ne = _ne,sw = _sw;

@end
