//
//  SponsoredPOIView.h
//  SponsoredPOIs
//
//  Created by Dmytro Golub on 8/20/09.
//  Copyright 2009 CloudMade. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMMarker.h"

@interface CMAnnotationView : UIView
{
	UIImageView* _leftBorder;
	UIImageView* _rightBorder;
	UIImageView* _middleView;
	UIImageView* _sparkViewLeft;
	UIImageView* _sparkViewRight;	
	UILabel* _poiName; 
	CGRect _frame;
	UIImageView* _icon;
}

-(void) anchorPoint:(CGPoint) point;
- (id)initWithFrame:(CGRect)frame andTitle:(NSString*) title  withImage:(UIImage*) image;
@end
