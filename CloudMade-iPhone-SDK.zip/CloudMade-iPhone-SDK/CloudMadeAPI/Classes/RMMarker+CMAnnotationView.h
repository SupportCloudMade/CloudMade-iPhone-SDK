/*
 *  RMMarker+CMAnnotationView.h
 *  CloudMadeApi
 *
 *  Created by user on 8/31/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#error : Please include file RMMarkerAdditions.h instead of this one 