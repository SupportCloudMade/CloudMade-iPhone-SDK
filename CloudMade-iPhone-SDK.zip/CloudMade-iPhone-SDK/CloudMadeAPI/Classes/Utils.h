//
//  Utils.h
//  CloudMadeApi
//
//  Created by Dmytro Golub on 11/5/09.
//  Copyright 2010 CloudMade. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Utils: NSObject 
{
}
+(UIImage*)scaleAndRotateImage:(UIImage*) image  withWidth:(float) maxWidth  withHeight:(float) maxHeight; 
+(UIImage*) getImage:(NSString*) strUrl;
+(NSArray*) getCategories:(NSString*) fileName; 
+(NSString*) encodeStringForURL:(NSString*) string;
@end
