/*
 *  CMRouteSammury.h
 *  CloudMadeApi
 *
 *  Created by user on 11/2/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#error : Please include file CMRouteSummary.h instead of this one 