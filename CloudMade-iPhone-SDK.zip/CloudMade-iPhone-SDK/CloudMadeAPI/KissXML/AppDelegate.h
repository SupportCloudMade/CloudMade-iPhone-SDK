#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject
{

}

@end
