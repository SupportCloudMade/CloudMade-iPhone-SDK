/*
 *  RMGlobalConstants.h
 *  MapView
 *
 *  Created by My Home on 4/29/09.
 *  Copyright 2009 Brandon "Quazie" Kwaselow. All rights reserved.
 *
 */

#define kMaxLong 180 
#define kMaxLat 90