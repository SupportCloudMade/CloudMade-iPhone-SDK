//
//  RMCloudMadeHiResMapSource.h
//  MapView
//
//  Created by CloudMade Inc. on 11/25/10.
//  Copyright 2010 CloudMade. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RMCloudMadeMapSource.h"

@interface RMCloudMadeHiResMapSource : RMCloudMadeMapSource {
	NSString* styleId;
}
@property (nonatomic, retain, readonly) NSString* styleId;

@end
