//
//  ___PROJECTNAMEASIDENTIFIER___ViewController.h
//  ___PROJECTNAME___
//
//  Created by user on 11/10/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMMapView.h"

@interface ___PROJECTNAMEASIDENTIFIER___ViewController : UIViewController {
	IBOutlet RMMapView* mapView;
}

@end

