/*
 *  testAddresses.h
 *  MapView
 *
 *  Created by user on 11/4/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#define TOKENSERVER @"10.1.3.227"
#define APIKEY      @"67a3e27e17f45df58f597cc00dc47bd7"