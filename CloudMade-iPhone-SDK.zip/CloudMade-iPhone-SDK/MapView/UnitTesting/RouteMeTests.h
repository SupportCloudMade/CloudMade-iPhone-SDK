//
//  RouteMeTests.h
//  MapView
//
//  Created by Hal Mueller on 4/6/09.
//  Copyright 2009 Route-Me Contributors. All rights reserved.
//

#import "GTMSenTestCase.h"
#import "GTMUIKit+UnitTesting.h"
#import <CoreLocation/CoreLocation.h>

@class RMMapView;

/// Unit tests go here. See http://developer.apple.com/tools/unittest.html 
///and http://code.google.com/p/google-toolbox-for-mac/wiki/iPhoneUnitTesting for guidance.
@interface RouteMeTests : SenTestCase {
	RMMapView *mapView;
	UIView *contentView;
	CLLocationCoordinate2D initialCenter;
}

@end
