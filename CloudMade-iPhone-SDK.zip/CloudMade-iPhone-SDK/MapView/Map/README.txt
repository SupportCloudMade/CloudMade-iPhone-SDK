The Route-Me project is receiving frequent updates from its developer community. For 
this reason, you'll probably want to have your hands on the source of Route-Me while 
you're developing your own project. If you want to link the Route-Me .xcodeproj to your
own program, please follow the Embedding Guide, found at
http://code.google.com/p/route-me/wiki/EmbedingGuide
Use the "MapView" target.

If you just want to produce a static library framework to drop into your app, without project 
dependencies or source-level debugging, follow the instructions in README-library-build.rtf
and use the "MapView-framework" target.


