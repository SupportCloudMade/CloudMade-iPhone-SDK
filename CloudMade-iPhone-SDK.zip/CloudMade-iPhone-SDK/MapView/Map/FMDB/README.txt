This is FMDB; an objective-c wrapper around SQLITE by August Mueller from here:
http://gusmueller.com/blog/archives/2008/03/fmdb_for_iphone.html